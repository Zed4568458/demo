<?php
defined( 'ABSPATH' ) or die();

add_filter( 'marlab_sidebar_id', 'marlab_single_sidebar' );
add_filter( 'marlab_sidebar_position', 'marlab_single_sidebar_position' );
?>

<?php if ( have_posts() ): the_post(); ?>

	<?php get_header() ?>
		<!-- The main content -->
		<?php get_template_part( 'tmpl/post/content', 'single' ) ?>

		<?php marlab_related_posts() ?>
		<?php marlab_comments_list() ?>

	<?php get_footer() ?>

<?php endif ?>	
