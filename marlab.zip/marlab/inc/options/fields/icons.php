<?php
defined( 'ABSPATH' ) or die();


/**
 * This class will be present an social icons control
 */
class Marlab_Options_Icons extends Marlab_Options_Control
{
	/**
	 * The control type
	 * 
	 * @var  string
	 */
	public $type = 'icons';
	public $default = array();

	public function render_content() {
		?>
			<div class="options-control-inputs">
				<icons v-bind:value="data" v-bind:icons="_marlabicons" v-on:change="triggerChange"></icons>
			</div>
		<?php
	}
}
