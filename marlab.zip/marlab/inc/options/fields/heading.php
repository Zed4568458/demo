<?php
defined( 'ABSPATH' ) or die();


/**
 * This class will be present an text control
 * for theme optionsr
 */
class Marlab_Options_Heading extends Marlab_Options_Control
{
	/**
	 * The control type
	 * 
	 * @var  string
	 */
	public $type = 'heading';
	
	/**
	 * Render the control markup
	 * 
	 * @return  void
	 */
	public function render_content() {
	}
}
