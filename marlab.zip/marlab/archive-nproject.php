<?php
defined( 'ABSPATH' ) or die();


add_filter( 'marlab_body_class', 'marlab_projects_body_class' );
add_filter( 'marlab_sidebar_id', 'marlab_projects_sidebar' );
add_filter( 'marlab_sidebar_position', 'marlab_projects_sidebar_position' );
?>

	<?php get_header() ?>
		<?php if ( have_posts() ): ?>
			<?php get_template_part( 'tmpl/project/loop', marlab_option( 'projects__displayMode' ) ) ?>
		<?php else: ?>
			<div class="content">
				<?php get_template_part( 'tmpl/project/content', 'none' ) ?>
			</div>
		<?php endif ?>
	<?php get_footer(); ?>

