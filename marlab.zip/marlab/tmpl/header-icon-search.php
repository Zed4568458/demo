<li class="search-box">
	<a href="#">
		<i class="iconlab iconlab-zoom-1"></i>
	</a>
	<?php the_widget( 'WP_Widget_Search' ) ?>
</li>