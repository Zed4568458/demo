<?php
defined( 'ABSPATH' ) or die();

function marlab_blog_body_class( $classes ) {
	$classes[] = sprintf( 'blog-%s', marlab_option( 'blog__archive__style' ) );

	return $classes;
}

function marlab_blog_sidebar() {
	return marlab_option( 'blog__archive__sidebar' );
}

function marlab_blog_sidebar_position() {
	return marlab_option( 'blog__archive__sidebarPosition' );
}

function marlab_single_sidebar() {
	return marlab_option( 'blog__single__sidebar' );
}

function marlab_single_sidebar_position() {
	return marlab_option( 'blog__single__sidebarPosition' );
}

